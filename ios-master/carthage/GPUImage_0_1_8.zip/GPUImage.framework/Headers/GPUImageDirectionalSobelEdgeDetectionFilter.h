#import "GPUImage3x3TextureSamplingFilter.h"

@interface GPUImageDirectionalSobelEdgeDetectionFilter : GPUImage3x3TextureSamplingFilter

@end
