//  Created by Jorge Garcia on 9/5/12.
//

#import "GPUImageTwoInputFilter.h"

@interface GPUImageNormalBlendFilter : GPUImageTwoInputFilter

@end
