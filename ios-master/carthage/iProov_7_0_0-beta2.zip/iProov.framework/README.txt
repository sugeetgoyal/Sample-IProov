Loco ios export: iOS Localizable.strings
Project: iProov
Release: Working copy
Exported at: Fri, 24 May 2019 10:39:38 +0100
Exported by: Jonathan Ellis